﻿namespace OrgChartGenerator {


    partial class OrgData
    {
        partial class OrgDetailsDataTable
        {
        }
    }
}
