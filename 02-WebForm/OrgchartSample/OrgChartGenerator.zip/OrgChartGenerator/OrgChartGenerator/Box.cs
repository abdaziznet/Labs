using System;
using System.Collections.Generic;
using System.Text;

namespace OrgChartGenerator
{
    public class Box
    {
        public int Width;
        public int Height;
        public System.Drawing.Color LineColor;
        public int LineWidth;
    }
}
